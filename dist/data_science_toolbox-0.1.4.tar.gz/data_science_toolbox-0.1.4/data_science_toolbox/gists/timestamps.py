from datetime import datetime
# Exact Time
now = datetime.now().strftime('%Y-%m-%d_%H:%M:%S')
# Todays date in lexicgraphical sort order
today = datetime.now().strftime('%Y%m%d')
