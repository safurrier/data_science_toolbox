## In Seaborn/Matplotlib
import seaborn as sns
sns.set(context='paper', style='darkgrid', rc={'figure.facecolor':'white'}, font_scale=1.2)

## In altair
alt.themes.enable('opaque')